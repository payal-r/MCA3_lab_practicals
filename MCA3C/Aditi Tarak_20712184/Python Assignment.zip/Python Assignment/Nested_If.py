# Aditi Tarak MCA-'3C'  DEHRADUN Campus STD ID-20712184

age = 22
isGraduated = False
hasLicense = True

if age >= 18:
    print("You're 18 or older. You can vote ")

    if isGraduated:
        print('Welcome to COllege Life')
    if hasLicense:
        print('You can apply for driving license too')