#Aditi Tarak MCA-'3C'  DEHRADUN Campus STD ID-20712184

print('Mathematical Operations in Python')
num1 = int(input('Enter First Number: '))
num2 = int(input('Enter Second Number '))
add = num1 + num2
dif = num1 - num2
mul = num1 * num2
div = num1 / num2
power = num1 ** num2
modulus = num1 % num2
print('Sum of ',num1 ,'and' ,num2 ,'is :',add)
print('Difference of ',num1 ,'and' ,num2 ,'is :',dif)
print('Product of' ,num1 ,'and' ,num2 ,'is :',mul)
print('Division of ',num1 ,'and' ,num2 ,'is :',div)
print('Exponent of ',num1 ,'and' ,num2 ,'is :',power)
print('Modulus of ',num1 ,'and' ,num2 ,'is :',modulus)