#Aditi Tarak MCA-'3C' DEHRADUN Campus STD ID-20712184

tuple1 = ("Aditi", 22, "Female")
print(tuple1)

tuple1 = ("GEU", "GEHU_DEHRADUN", "GEHU_DEEHRADUN")
tuple2 = (1, 2, 3)
print(tuple1)
print(tuple2)