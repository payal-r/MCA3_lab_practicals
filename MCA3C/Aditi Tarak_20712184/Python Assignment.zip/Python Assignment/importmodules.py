# Aditi Tarak MCA-'3C'  DEHRADUN Campus STD ID-20712184

from math import *

import math
print(math.pi)

print(math.sin(math.pi/2))
print(factorial(6))