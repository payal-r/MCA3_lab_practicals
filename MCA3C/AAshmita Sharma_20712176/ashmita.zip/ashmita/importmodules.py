# ashmita sharma MCA 3 - DEHRADUN Campus STD ID-20712176

from math import *

import math
print(math.pi)

print(math.sin(math.pi/2))
print(factorial(6))