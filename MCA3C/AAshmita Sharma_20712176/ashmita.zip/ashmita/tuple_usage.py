#ashmita sharma MCA 3 - DEHRADUN Campus STD ID-20712176

tuple1 = ("Sudarshan", 24, "Male")
print(tuple1)

tuple1 = ("GEU", "GEHU_DEHRADUN", "GEHU_DEEHRADUN")
tuple2 = (1, 2, 3)
print(tuple1)
print(tuple2)