# ashmita sharma MCA 3 - DEHRADUN Campus STD ID-20712176

str = [110, 21, 18, 38, 36]
print(sorted(str))  # with sorting
print(str)  # without sorting

index = str.index(38)
print(index)

index = str.index(110)
print(index)