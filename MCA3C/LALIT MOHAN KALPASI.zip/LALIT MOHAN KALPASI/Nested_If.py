age = 19
Graduated = False
License = True

if age >= 18:
    print("You're 18 or older. You can vote ")

    if Graduated:
        print('Welcome to COllege Life')
    if License:
        print('You can apply for driving license too')