str = [70, 15, 18, 38, 26]
print(sorted(str))  # with sorting
print(str)  # without sorting

index = str.index(38)
print(index)

index = str.index(26)
print(index)