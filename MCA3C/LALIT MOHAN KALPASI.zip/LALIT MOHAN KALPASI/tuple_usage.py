tuple1 = ("lalit", 23, "MALE")
print(tuple1)

tuple1 = ("GEU", "GEHU_DEHRADUN", "GEHU_DEEHRADUN")
tuple2 = (1, 2, 3)
print(tuple1)
print(tuple2)