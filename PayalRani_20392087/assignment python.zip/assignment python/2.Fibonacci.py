# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#2. write a program to take an input of numbers
#from the user and print the Fibonacci series to the terminal number.

x=0
y=1
i=0
while(i<=10):
    if(i<=1):
        z=i
    else:
        z=x+y
        x=y
        y=z
    print(z)
    i=i+1
   
