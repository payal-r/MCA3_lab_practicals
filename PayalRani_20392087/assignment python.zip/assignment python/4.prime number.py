# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#Write a program to check whether a given number is a prime number
#or not using loops.

Num = int(input(" Please Enter any Number: "))
c = 0

for i in range(2, (Num//2 + 1)):
    if(Num % i == 0):
        c = c + 1
        break

if (c == 0 and Num != 1):
    print(" this is a Prime Number" ,Num)
else:
    print(" this is not a Prime Number" ,Num)



