# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#9. Write a program for searching an element and sorting a List.

list1=["banana","orange","kiwi","cherry","Apple"]
list2=[56,78,45,23,25,56]

#1.
list1.sort()
list2.sort()
print(list1)
print(list2)

#2.
list1.reverse()
list2.reverse()
print(list1)
print(list2)

#3.
list3=list1.copy()
print(list3)
