# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#3.Write a program to print the factorial of the number input by the user.

num = int(input("Enter a number: "))    
factorial = 1        
for i in range(1,num + 1):    
    factorial = factorial*i    
print("The factorial of",num,"is",factorial)    

