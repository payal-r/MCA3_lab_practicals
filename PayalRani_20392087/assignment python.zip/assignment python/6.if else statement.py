# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#6.Write a program to demonstrate the use of nested if statements

a=int(input("enter any value in a:"))
b=int(input("enter any value in b:"))
c=int(input("enter any value in c:"))

if(a>b and a>c):
    print("A is greatest")
elif(b>a and b>c):
    print("B is greatest")

else:
    print("c is greatest")



#2;

age=int(input("enter your age:"))
height=int(input("enter your height:"))

if(age>=18 and height>=5.7):
    print("It is eligible")

else:
    print("It is not eligible")
