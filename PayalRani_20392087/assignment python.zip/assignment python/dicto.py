# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087
#10.Write a program to illustrate the usage of Dictionaries.


#1.
Dict = dict([(1, 'Apple'), (2, 'Banana')])
print("\nDictionary with each item as a pair: ")
print(Dict)

#2.

Dict={"brand":"ford","model":"mustang","year":1964}
print(Dict)

Dict["color"]="red"
print(Dict)

j=Dict.pop("model")
print(Dict)
print(j)

#3.

Dict={"brand":"ford","model":"mustang","year":1964}
print(Dict)
i=Dict.popitem()
print(Dict)
print(i)

#4.
Dict={"brand":"ford","model":"mustang","year":1964}
print(Dict)
NewDict=Dict.copy()
print("New Dictionary 1:",NewDict)

#5.
Dict={"brand":"ford","model":"mustang","year":1964}
print(Dict)
Dict.clear()
print(Dict)

