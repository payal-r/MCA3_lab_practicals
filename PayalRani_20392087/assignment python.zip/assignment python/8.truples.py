# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#8.Write a program to illustrate the usage of Tuples.

#1.
print("** even number **")

trpl=(25,45,7,34,14)
print(trpl)
for a in trpl:
    if(a%2==0):
        print("even= ",a)

#2.

print("** sum of even number **")
trpl=(25,45,7,34,14)

s=0
print("even number are:")
for a in trpl:
    if(a%2==0):
        s=s+a
        print(a,end="")
print("\n\n Sum of even number:",s)



#3.count total even and odd even

print("** count total even and odd even **")

trpl=(25,45,7,34,14,44,68)
s=0
even=0
odd=0
print(trpl)
print("even number are:")
for a in trpl:
    if(a%2==0):
        even=even+1
    else:
        odd=odd+1
l=len(trpl)
print("length of trpl is:",l)
print("\n\n Total even number are:",even)
print("\n\n Total odd number are:",odd)
