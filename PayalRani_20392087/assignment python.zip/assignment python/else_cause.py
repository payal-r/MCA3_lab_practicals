# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

num = int(input("Enter your Number: "))

if num >= 100:
    print("Number is Greater than 100")
else:
    print("Number is Less than 100")
