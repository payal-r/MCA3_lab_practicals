# Payal Rani MCA-'3C'  DEHRADUN Campus STD ID-20392087

#9. Write a program for searching an element and sorting a List.

#1.
lst=[10,20,30,40,50,60]
print("Actual list is:",lst)

n=len(lst)
i=0
while(i<n):
    for j in range(i+1,i+2,+2):
        t=lst[i]
        lst[i]=lst[j]
        lst[j]=t
    i=i+2
print("\n\n sorted list is:",lst)

#2.
lst=[21,20,34,4,54,90]
print("Actual list is:",lst)
n=len(lst)
i=0
while(i<n):
    for j in range(1,i+2,+2):
        if(lst[j]%5==0):
            t=lst[i]
            lst[i]=lst[j]
            lst[j]=t
        i=i+2
print("\n\n sorted list is:",lst)

#3.
lst=[10,20,30,40,50,60]
print("Actual list is:",lst)
n=len(lst)
mid=int(n/2)
i=0
while(i<mid+1):
    for j in range(mid,n,+1):
            t=lst[i]
            lst[i]=lst[j]
            lst[j]=t
    i=i+1
print("\n\n sorted list is:",lst)
